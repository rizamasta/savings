var App = angular.module('savings.controllers',[]);

App.controller('AppCtrl', function($scope,isLogin) {
  //localStorage.clear();
  isLogin.getLogin();
});

App.controller('LoginCtrl',function($scope,$http,$state,isLogin,urlEncode,urlBase){
    $scope.form= {};
    $scope.loginTask = function(){
      $http({
        method : 'POST',
        url    : urlBase.gateway('login'),
        data   : urlEncode.setValue($scope.form),
        headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }
      })
          .success(function(data){
            $scope.result = data;
            if($scope.result.message=="success"){
              $scope.authMsg = "";
              isLogin.setLogin($scope.result);
              $state.go('app.playlists');

            }
            else{
              $scope.authMsg = $scope.result.message;
            }

          })
          .error(function(e){
            $scope.authMsg = "Error "+e;
          });

    };

});

App.controller('ReportCtrl', function($scope,isLogin,$http,urlBase,urlEncode) {
  var data_login = isLogin.getLogin(),
      data_user  = data_login.result[0];
  $scope.data    = {
    username:data_user.user_name
  };
  $scope.loadData = function(){
    $http({
    method : 'POST',
    url    : urlBase.gateway('tabungan/report'),
    data   : urlEncode.setValue($scope.data),
    headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }
  })
      .success(function(data){
        $scope.result = data;
        if($scope.result.message=="success"){
          $scope.report   = $scope.result.data;
          $scope.deposit  = $scope.result.deposit[0];
          $scope.debt     = $scope.result.debt[0];
          $scope.pay_debt = $scope.result.pay_debt[0];
          $scope.saldo    = ($scope.deposit.total_deposit-$scope.debt.total_debt)+parseInt($scope.pay_debt.total_pay_debt);
        }
        else{
          $scope.msg=$scope.result.message;
        }
      })
      .error(function(e){
        $scope.msg= "e";
      });
  };
    $scope.loadData();
});

App.controller('addSavings',function($scope,$http,urlBase,urlEncode,isLogin,$timeout){
  var data_login = isLogin.getLogin(),
      data_user  = data_login.result[0];
  $scope.form = {
    jumlah:1000,
    username:data_user.user_name,
    type:'deposit'
  };
  $scope.simpan = function(){
    if($scope.form.jumlah>=1000){
      $http({
        method  : 'POST',
        url     : urlBase.gateway('tabungan/add'),
        data    : urlEncode.setValue($scope.form),
        headers : {'Content-Type' : 'application/x-www-form-urlencoded'}
      })
          .success(function(data){
            $scope.result   = data;
            if($scope.result.message =="success"){
              $scope.msg  ="";
              $scope.text = $scope.result.text;
              $timeout(function() {
                $scope.text=""; //close the popup after 3 seconds for some reason
              }, 1000);

            }
            else{
              $scope.msg = $scope.result.message;
            }
          })
          .error(function (e) {
            console.log(e);
            $scope.msg  ="Please Contact Our Support";
          })
    }
    else{
      $scope.msg = "Minimal 1000";
    }
  };
});

App.controller('addDebt',function($scope,$http,urlBase,urlEncode,isLogin,$timeout){
  var data_login = isLogin.getLogin(),
      data_user  = data_login.result[0],
      save;
  $scope.form = {
    jumlah:1000,
    username:data_user.user_name,
    type:'debt'
  };
  $http({
    method : 'POST',
    url    : urlBase.gateway('tabungan/report'),
    data   : urlEncode.setValue($scope.form),
    headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }
  })
      .success(function(data){
        $scope.result = data;
        if($scope.result.message=="success"){
          $scope.deposit  = $scope.result.deposit[0];
          $scope.debt     = $scope.result.debt[0];
          $scope.pay_debt = $scope.result.pay_debt[0];
          save            = ($scope.deposit.total_deposit-$scope.debt.total_debt)+parseInt($scope.pay_debt.total_pay_debt);
          $scope.saldo    = save -(save*0.2);
        }
        else{
          $scope.msg=$scope.result.message;
        }
      })
      .error(function(e){
        $scope.msg= "e";
      });
  $scope.simpan = function(){
    var max =save -(save*0.2);
    if($scope.form.jumlah<=max){
      $http({
        method  : 'POST',
        url     : urlBase.gateway('tabungan/add'),
        data    : urlEncode.setValue($scope.form),
        headers : {'Content-Type' : 'application/x-www-form-urlencoded'}
      })
          .success(function(data){
            $scope.result   = data;
            if($scope.result.message =="success"){
              $scope.msg  ="";
              $scope.text = $scope.result.text;
              $timeout(function() {
                $scope.text=""; //close the popup after 3 seconds for some reason
              }, 1000);

            }
            else{
              $scope.msg = $scope.result.message;
            }
          })
          .error(function (e) {
            console.log(e);
            $scope.msg  ="Please Contact Our Support";
          })
    }
    else{
      $scope.msg = "Maximal "+max;
    }
  };
});

App.controller('payDebt',function($scope,$http,urlBase,urlEncode,isLogin,$timeout){
  var data_login = isLogin.getLogin(),
      data_user  = data_login.result[0],
      save;
  $scope.form = {
    jumlah:0,
    username:data_user.user_name,
    type:'pay-debt'
  };
  $http({
    method : 'POST',
    url    : urlBase.gateway('tabungan/report'),
    data   : urlEncode.setValue($scope.form),
    headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }
  })
      .success(function(data){
        $scope.result = data;
        if($scope.result.message=="success"){
          $scope.deposit  = $scope.result.deposit[0];
          $scope.debt     = $scope.result.debt[0];
          $scope.pay_debt = $scope.result.pay_debt[0];
          save            = parseInt($scope.debt.total_debt)- parseInt($scope.pay_debt.total_pay_debt);
          $scope.maximal  = save;
          $scope.form.jumlah = save;
        }
        else{
          $scope.msg=$scope.result.message;
        }
      })
      .error(function(e){
        $scope.msg= "e";
      });
  $scope.simpan = function(){
    if($scope.form.jumlah<=save){
      $http({
        method  : 'POST',
        url     : urlBase.gateway('tabungan/add'),
        data    : urlEncode.setValue($scope.form),
        headers : {'Content-Type' : 'application/x-www-form-urlencoded'}
      })
          .success(function(data){
            $scope.result   = data;
            if($scope.result.message =="success"){
              $scope.msg  ="";
              $scope.text = $scope.result.text;
              $timeout(function() {
                $scope.text=""; //close the popup after 3 seconds for some reason
              }, 1000);

            }
            else{
              $scope.msg = $scope.result.message;
            }
          })
          .error(function (e) {
            console.log(e);
            $scope.msg  ="Please Contact Our Support";
          })
    }
    else{
      $scope.msg = "Maximal "+save;
    }
  };
});

App.controller('LogoutCtrl',function($state,isLogin){
  localStorage.clear();
  isLogin.getLogin();
});

